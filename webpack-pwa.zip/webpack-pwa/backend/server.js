const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const webpush = require('web-push');
const sqlite3 = require('sqlite3').verbose();
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Configurar VAPID keys para push notifications
webpush.setVapidDetails(
  process.env.VAPID_EMAIL || 'mailto:admin@example.com',
  process.env.VAPID_PUBLIC_KEY,
  process.env.VAPID_PRIVATE_KEY
);

// Inicializar banco de dados SQLite
const db = new sqlite3.Database('./database.db');

// Criar tabelas
db.serialize(() => {
  // Tabela de usuários
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Tabela de subscriptions para push notifications
  db.run(`CREATE TABLE IF NOT EXISTS subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    endpoint TEXT NOT NULL,
    p256dh TEXT NOT NULL,
    auth TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  )`);

  // Criar usuário admin padrão
  const adminPassword = bcrypt.hashSync('admin123', 10);
  db.run(`INSERT OR IGNORE INTO users (username, password) VALUES (?, ?)`, 
    ['admin', adminPassword]);
});

// Middleware de autenticação
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token de acesso requerido' });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'default_secret', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Token inválido' });
    }
    req.user = user;
    next();
  });
};

// Rotas de autenticação
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Username e password são obrigatórios' });
  }

  db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }

    if (!user || !bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    const token = jwt.sign(
      { id: user.id, username: user.username },
      process.env.JWT_SECRET || 'default_secret',
      { expiresIn: '24h' }
    );

    res.json({
      message: 'Login realizado com sucesso',
      token,
      user: { id: user.id, username: user.username }
    });
  });
});

// Rota para verificar se o token é válido
app.get('/api/verify', authenticateToken, (req, res) => {
  res.json({ 
    message: 'Token válido', 
    user: { id: req.user.id, username: req.user.username } 
  });
});

// Rota para obter a chave pública VAPID
app.get('/api/vapid-public-key', (req, res) => {
  res.json({ 
    publicKey: process.env.VAPID_PUBLIC_KEY || 'BEl62iUYgUivxIkv69yViEuiBIa40HI8YlOu_7YmFBSKjQOtfzPEtfKbI4p5dC0QwPLAZp5VQ1A8pf-MYonIFHE'
  });
});

// Rota para salvar subscription de push notification
app.post('/api/subscribe', authenticateToken, (req, res) => {
  const { endpoint, keys } = req.body;
  const userId = req.user.id;

  if (!endpoint || !keys || !keys.p256dh || !keys.auth) {
    return res.status(400).json({ error: 'Dados de subscription inválidos' });
  }

  // Verificar se já existe uma subscription para este usuário
  db.get('SELECT * FROM subscriptions WHERE user_id = ?', [userId], (err, existingSubscription) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }

    if (existingSubscription) {
      // Atualizar subscription existente
      db.run(`UPDATE subscriptions SET endpoint = ?, p256dh = ?, auth = ? WHERE user_id = ?`,
        [endpoint, keys.p256dh, keys.auth, userId], (err) => {
          if (err) {
            return res.status(500).json({ error: 'Erro ao atualizar subscription' });
          }
          res.json({ message: 'Subscription atualizada com sucesso' });
        });
    } else {
      // Criar nova subscription
      db.run(`INSERT INTO subscriptions (user_id, endpoint, p256dh, auth) VALUES (?, ?, ?, ?)`,
        [userId, endpoint, keys.p256dh, keys.auth], (err) => {
          if (err) {
            return res.status(500).json({ error: 'Erro ao salvar subscription' });
          }
          res.json({ message: 'Subscription salva com sucesso' });
        });
    }
  });
});

// Rota para enviar push notification para todos os usuários
app.post('/api/send-notification', authenticateToken, (req, res) => {
  const { title, body, icon } = req.body;

  if (!title || !body) {
    return res.status(400).json({ error: 'Título e corpo da notificação são obrigatórios' });
  }

  const payload = JSON.stringify({
    title,
    body,
    icon: icon || '/icon-192x192.png',
    badge: '/icon-192x192.png',
    timestamp: Date.now()
  });

  // Buscar todas as subscriptions
  db.all('SELECT * FROM subscriptions', [], (err, subscriptions) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao buscar subscriptions' });
    }

    if (subscriptions.length === 0) {
      return res.json({ message: 'Nenhuma subscription encontrada' });
    }

    const promises = subscriptions.map(subscription => {
      const pushSubscription = {
        endpoint: subscription.endpoint,
        keys: {
          p256dh: subscription.p256dh,
          auth: subscription.auth
        }
      };

      return webpush.sendNotification(pushSubscription, payload)
        .catch(err => {
          console.error('Erro ao enviar notificação:', err);
          // Remove subscription inválida
          if (err.statusCode === 410) {
            db.run('DELETE FROM subscriptions WHERE id = ?', [subscription.id]);
          }
        });
    });

    Promise.allSettled(promises).then(() => {
      res.json({ 
        message: `Notificação enviada para ${subscriptions.length} usuário(s)`,
        sent: subscriptions.length
      });
    });
  });
});

// Rota para obter estatísticas
app.get('/api/stats', authenticateToken, (req, res) => {
  db.get('SELECT COUNT(*) as total_users FROM users', [], (err, userCount) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }

    db.get('SELECT COUNT(*) as total_subscriptions FROM subscriptions', [], (err, subCount) => {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }

      res.json({
        totalUsers: userCount.total_users,
        totalSubscriptions: subCount.total_subscriptions
      });
    });
  });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
  console.log(`Acesse: http://localhost:${PORT}`);
});
