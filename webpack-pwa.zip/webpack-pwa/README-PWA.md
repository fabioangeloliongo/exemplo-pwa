# PWA com Push Notifications

Uma Progressive Web App (PWA) completa com sistema de autenticação JWT e push notifications.

## 🚀 Funcionalidades

- **Autenticação JWT**: Login seguro com tokens
- **Push Notifications**: Envio de notificações para usuários inscritos
- **PWA Completa**: Instalável, funciona offline
- **Painel Administrativo**: Interface para enviar notificações
- **Responsivo**: Funciona em desktop e mobile

## 📁 Estrutura do Projeto

```
webpack-pwa/
├── backend/                 # Servidor Node.js
│   ├── server.js           # Servidor principal
│   ├── package.json        # Dependências do backend
│   ├── .env               # Variáveis de ambiente
│   └── database.db        # Banco SQLite (criado automaticamente)
├── src/                    # Frontend PWA
│   ├── index.html         # Página principal
│   ├── app.js            # Lógica da aplicação
│   ├── sw.js             # Service Worker
│   ├── manifest.json     # Manifest PWA
│   └── *.svg             # Ícones da aplicação
└── generate-icons.js      # Script para gerar ícones
```

## 🛠️ Instalação e Execução

### 1. Backend

```bash
cd backend
npm install
npm start
```

O servidor rodará em `http://localhost:3001`

### 2. Frontend

```bash
# Gerar ícones
node generate-icons.js

# Servir arquivos estáticos (use qualquer servidor web)
cd src
python3 -m http.server 8000
# ou
npx serve .
# ou
php -S localhost:8000
```

O frontend estará disponível em `http://localhost:8000`

## 🔐 Credenciais Padrão

- **Usuário**: `admin`
- **Senha**: `admin123`

## 📱 Como Usar

1. **Acesse a aplicação** no navegador
2. **Faça login** com as credenciais padrão
3. **Permita notificações** quando solicitado
4. **Use o painel admin** para enviar push notifications
5. **Instale a PWA** clicando no botão "Instalar App"

## 🔧 Configuração

### Variáveis de Ambiente (backend/.env)

```env
JWT_SECRET=sua_chave_jwt_secreta
VAPID_PUBLIC_KEY=sua_chave_publica_vapid
VAPID_PRIVATE_KEY=sua_chave_privada_vapid
VAPID_EMAIL=mailto:seu-email@exemplo.com
PORT=3001
```

### Gerar Chaves VAPID

Para gerar suas próprias chaves VAPID:

```bash
npm install -g web-push
web-push generate-vapid-keys
```

## 🌐 API Endpoints

### Autenticação
- `POST /api/login` - Fazer login
- `GET /api/verify` - Verificar token

### Push Notifications
- `GET /api/vapid-public-key` - Obter chave pública VAPID
- `POST /api/subscribe` - Inscrever para notificações
- `POST /api/send-notification` - Enviar notificação (requer auth)

### Estatísticas
- `GET /api/stats` - Obter estatísticas (requer auth)

## 🔄 Funcionalidades PWA

- **Instalável**: Pode ser instalada como app nativo
- **Offline**: Funciona sem conexão (cache)
- **Push Notifications**: Recebe notificações mesmo com app fechado
- **Responsivo**: Adapta-se a diferentes tamanhos de tela
- **Seguro**: Funciona apenas via HTTPS (em produção)

## 🚀 Deploy em Produção

### Backend
1. Configure as variáveis de ambiente
2. Use um processo manager como PM2
3. Configure proxy reverso (Nginx)
4. Use HTTPS

### Frontend
1. Sirva os arquivos via HTTPS
2. Configure Service Worker corretamente
3. Teste em diferentes dispositivos

## 🛡️ Segurança

- Tokens JWT com expiração
- Senhas hasheadas com bcrypt
- CORS configurado
- Validação de dados de entrada
- HTTPS obrigatório em produção

## 📊 Banco de Dados

Usa SQLite com as seguintes tabelas:

- **users**: Usuários do sistema
- **subscriptions**: Inscrições para push notifications

## 🎨 Personalização

- Modifique `src/index.html` para alterar a interface
- Edite `src/app.js` para adicionar funcionalidades
- Customize `src/manifest.json` para mudar informações da PWA
- Altere `generate-icons.js` para criar ícones personalizados

## 🐛 Troubleshooting

### Push Notifications não funcionam
- Verifique se está usando HTTPS
- Confirme as chaves VAPID
- Teste permissões do navegador

### PWA não instala
- Verifique o manifest.json
- Confirme se está servindo via HTTPS
- Teste o Service Worker

### Problemas de CORS
- Configure o backend para aceitar seu domínio
- Verifique as headers de CORS

## 📝 Licença

MIT License - veja o arquivo original para detalhes.
