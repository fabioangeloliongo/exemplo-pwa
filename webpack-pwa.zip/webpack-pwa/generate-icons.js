// Script para gerar ícones SVG simples para a PWA
const fs = require('fs');
const path = require('path');

// Função para criar ícone SVG
function createIcon(size) {
  const svg = `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" rx="20%" fill="url(#grad)"/>
  <text x="50%" y="50%" font-family="Arial, sans-serif" font-size="${size * 0.4}" fill="white" text-anchor="middle" dy="0.35em">📱</text>
</svg>`;
  
  return svg;
}

// Criar diretório src se não existir
const srcDir = path.join(__dirname, 'src');
if (!fs.existsSync(srcDir)) {
  fs.mkdirSync(srcDir);
}

// Gerar ícones
const icon192 = createIcon(192);
const icon512 = createIcon(512);

// Salvar ícones como SVG (podem ser convertidos para PNG depois)
fs.writeFileSync(path.join(srcDir, 'icon-192x192.svg'), icon192);
fs.writeFileSync(path.join(srcDir, 'icon-512x512.svg'), icon512);

console.log('Ícones SVG gerados com sucesso!');
console.log('Para converter para PNG, use uma ferramenta como ImageMagick ou um conversor online.');
console.log('Comandos para converter (se tiver ImageMagick instalado):');
console.log('convert src/icon-192x192.svg src/icon-192x192.png');
console.log('convert src/icon-512x512.svg src/icon-512x512.png');
