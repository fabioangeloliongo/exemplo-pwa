// Configuração da API
const API_BASE_URL = 'http://localhost:3001/api';

// Estado da aplicação
let currentUser = null;
let deferredPrompt = null;

// Elementos DOM
const homeScreen = document.getElementById('homeScreen');
const loginScreen = document.getElementById('loginScreen');
const adminScreen = document.getElementById('adminScreen');
const loginForm = document.getElementById('loginForm');
const loginError = document.getElementById('loginError');
const logoutBtn = document.getElementById('logoutBtn');
const notificationForm = document.getElementById('notificationForm');
const notificationResult = document.getElementById('notificationResult');
const notificationError = document.getElementById('notificationError');
const adminAccessBtn = document.getElementById('adminAccessBtn');
const backToHomeBtn = document.getElementById('backToHomeBtn');
const installBtnHome = document.getElementById('installBtnHome');

// Inicialização da aplicação
document.addEventListener('DOMContentLoaded', () => {
    checkAuthStatus();
    registerServiceWorker();
    setupInstallPrompt();
    setupEventListeners();
});

// Verificar se o usuário já está logado
function checkAuthStatus() {
    const token = localStorage.getItem('authToken');
    if (token) {
        fetch(`${API_BASE_URL}/verify`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
        .then(response => {
            if (response.ok) {
                return response.json();
            }
            throw new Error('Token inválido');
        })
        .then(data => {
            currentUser = data.user;
            showAdminScreen();
        })
        .catch(() => {
            localStorage.removeItem('authToken');
            showHomeScreen();
        });
    } else {
        showHomeScreen();
    }
}

// Configurar event listeners
function setupEventListeners() {
    loginForm.addEventListener('submit', handleLogin);
    logoutBtn.addEventListener('click', handleLogout);
    notificationForm.addEventListener('submit', handleSendNotification);
    adminAccessBtn.addEventListener('click', showLoginScreen);
    backToHomeBtn.addEventListener('click', showHomeScreen);
    installBtnHome.addEventListener('click', handleInstallApp);
}

// Handle login
async function handleLogin(e) {
    e.preventDefault();
    
    const formData = new FormData(loginForm);
    const credentials = {
        username: formData.get('username'),
        password: formData.get('password')
    };

    try {
        const response = await fetch(`${API_BASE_URL}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(credentials)
        });

        const data = await response.json();

        if (response.ok) {
            localStorage.setItem('authToken', data.token);
            currentUser = data.user;
            loginError.textContent = '';
            showAdminScreen();
            
            // Solicitar permissão para notificações após login
            requestNotificationPermission();
        } else {
            loginError.textContent = data.error || 'Erro ao fazer login';
        }
    } catch (error) {
        loginError.textContent = 'Erro de conexão com o servidor';
        console.error('Erro no login:', error);
    }
}

// Handle logout
function handleLogout() {
    localStorage.removeItem('authToken');
    currentUser = null;
    showHomeScreen();
}

// Handle send notification
async function handleSendNotification(e) {
    e.preventDefault();
    
    const formData = new FormData(notificationForm);
    const notification = {
        title: formData.get('title'),
        body: formData.get('body'),
        icon: formData.get('icon') || '/icon-192x192.png'
    };

    const sendBtn = document.getElementById('sendBtn');
    sendBtn.disabled = true;
    sendBtn.textContent = 'Enviando...';

    try {
        const token = localStorage.getItem('authToken');
        const response = await fetch(`${API_BASE_URL}/send-notification`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(notification)
        });

        const data = await response.json();

        if (response.ok) {
            notificationResult.textContent = data.message;
            notificationError.textContent = '';
            notificationForm.reset();
            loadStats(); // Atualizar estatísticas
        } else {
            notificationError.textContent = data.error || 'Erro ao enviar notificação';
            notificationResult.textContent = '';
        }
    } catch (error) {
        notificationError.textContent = 'Erro de conexão com o servidor';
        notificationResult.textContent = '';
        console.error('Erro ao enviar notificação:', error);
    } finally {
        sendBtn.disabled = false;
        sendBtn.textContent = 'Enviar Notificação';
    }
}

// Mostrar tela inicial
function showHomeScreen() {
    homeScreen.classList.remove('hidden');
    loginScreen.classList.add('hidden');
    adminScreen.classList.add('hidden');
}

// Mostrar tela de login
function showLoginScreen() {
    homeScreen.classList.add('hidden');
    loginScreen.classList.remove('hidden');
    adminScreen.classList.add('hidden');
}

// Mostrar painel administrativo
function showAdminScreen() {
    homeScreen.classList.add('hidden');
    loginScreen.classList.add('hidden');
    adminScreen.classList.remove('hidden');
    loadStats();
}

// Carregar estatísticas
async function loadStats() {
    try {
        const token = localStorage.getItem('authToken');
        const response = await fetch(`${API_BASE_URL}/stats`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            document.getElementById('totalUsers').textContent = data.totalUsers;
            document.getElementById('totalSubscriptions').textContent = data.totalSubscriptions;
        }
    } catch (error) {
        console.error('Erro ao carregar estatísticas:', error);
    }
}

// Registrar Service Worker
async function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        try {
            const registration = await navigator.serviceWorker.register('/sw.js');
            console.log('Service Worker registrado:', registration);
            
            // Escutar por atualizações do SW
            registration.addEventListener('updatefound', () => {
                console.log('Nova versão do Service Worker disponível');
            });
        } catch (error) {
            console.error('Erro ao registrar Service Worker:', error);
        }
    }
}

// Solicitar permissão para notificações
async function requestNotificationPermission() {
    if ('Notification' in window && 'serviceWorker' in navigator) {
        const permission = await Notification.requestPermission();
        
        if (permission === 'granted') {
            console.log('Permissão para notificações concedida');
            subscribeToNotifications();
        } else {
            console.log('Permissão para notificações negada');
        }
    }
}

// Inscrever-se para receber notificações push
async function subscribeToNotifications() {
    try {
        const registration = await navigator.serviceWorker.ready;
        
        // Obter chave pública VAPID
        const vapidResponse = await fetch(`${API_BASE_URL}/vapid-public-key`);
        const { publicKey } = await vapidResponse.json();
        
        // Criar subscription
        const subscription = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(publicKey)
        });

        // Enviar subscription para o servidor
        const token = localStorage.getItem('authToken');
        await fetch(`${API_BASE_URL}/subscribe`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(subscription)
        });

        console.log('Inscrito para notificações push');
    } catch (error) {
        console.error('Erro ao se inscrever para notificações:', error);
    }
}

// Converter chave VAPID para Uint8Array
function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
        .replace(/-/g, '+')
        .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
        outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
}

// Configurar prompt de instalação PWA
function setupInstallPrompt() {
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        installPrompt.classList.remove('hidden');
    });

    window.addEventListener('appinstalled', () => {
        console.log('PWA instalada');
        installPrompt.classList.add('hidden');
        deferredPrompt = null;
    });
}

// Handle install app
async function handleInstallApp() {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        console.log(`Resultado da instalação: ${outcome}`);
        deferredPrompt = null;
        installPrompt.classList.add('hidden');
    }
}
