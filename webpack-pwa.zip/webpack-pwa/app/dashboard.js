import * as page from "./dashboard/page";
import { bootstrap } from "./app";
bootstrap(page);
