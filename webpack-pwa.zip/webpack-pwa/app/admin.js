import { bootstrapAsync } from "./app";
bootstrapAsync("admin");
