import * as page from "./login/page";
import { bootstrap } from "./app";
bootstrap(page);
